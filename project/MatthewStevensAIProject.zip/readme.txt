compile using g++ -std=c++11 neural.cpp neuralNetwork.cpp
run with ./neuralNetwork 11111111 (binary string 35 in length) or ./neuralNetwork 0xNN 0xMM ... (5 hex inputs separated by spaces)