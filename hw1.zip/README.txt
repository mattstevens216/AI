compile all the programs using:
g++-7.2.0 -std=c++17 file.cpp

