//Name: Matthew Stevens
//UIN: 924000693
//CSCE 420
//Due: March 26, 2018
//README.txt

First, run gprolog in the directory containing the executables, I used the compute server.
Next, compile the executables, ex: [hw3pr1].

For program 1, run by doing: magical(X). or horned(X). or mythical(X).
the two unicorns are u and u1.

For program 2, run by doing: path(X, start, finish) where start is the starting city and finish is the starting city. ex: path(X,a,b).

For program 3, run by doing: mother(X, name). or grandchild(X, name). or brother_in_law(X, name). or sister_in_law(X, name). or great_grandparent(X, name). or ancestor(X, name). or first_cousin(name, X). or visa-versa for the variable and name. name is the name of a person, for example, diana.

for program 4, run by doing: my_sorted(list). where list is any list of ints.
my_perm(X, list). where list is a list of ints without repeating numbers, for example list may be [1,2,3,4] but not [1,2,3,4,1]. this may be run where X and list are swapped.
my_sort(list, M). where list is any list of ints without repeating numbers.
